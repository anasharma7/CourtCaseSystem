/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package m02a02;
import m02a02.Model.User;
import m02a02.View.UserView;
import m02a02.Controller.UserController;

public class M02A02 {

    public static void main(String[] args) {
        // Instantiate models
        User user = new User("username", "password", User.UserRole.ADMIN);
        // Instantiate views
        UserView userView = new UserView();
        // Instantiate controllers
        UserController userController = new UserController(user, userView);

        // Call methods to start your application logic
        userController.updateUserView();
    }
}
